package com.company;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
public static void print(List<WeightedVertex> weightedVertex){
    weightedVertex.forEach(weightedVertex1 -> {
        String path = weightedVertex1.getShortest().stream()
                .map(WeightedVertex::getName)
                .collect(Collectors.joining(" -> "));
        System.out.println(path.isBlank()
                ? "%s : %s".formatted(weightedVertex1.getName(), weightedVertex1.getDistance())
                : "%s -> %s : %s".formatted(path, weightedVertex1.getName(), weightedVertex1.getDistance())
        );
    });
}
    public static void main(String[] args) {
        Dijkstra dijkstra = new Dijkstra();

        WeightedVertex vertexA = new WeightedVertex("A");
        WeightedVertex vertexB = new WeightedVertex("B");
        WeightedVertex vertexC = new WeightedVertex("C");
        WeightedVertex vertexD = new WeightedVertex("D");
        WeightedVertex vertexE = new WeightedVertex("E");
        WeightedVertex vertexF = new WeightedVertex("F");

        vertexA.addVertex(vertexB, 2);
        vertexA.addVertex(vertexC, 4);

        vertexB.addVertex(vertexC, 3);
        vertexB.addVertex(vertexD, 1);
        vertexB.addVertex(vertexE, 5);

        vertexC.addVertex(vertexD, 2);

        vertexD.addVertex(vertexE, 1);
        vertexD.addVertex(vertexF, 4);

        vertexE.addVertex(vertexF, 2);

        dijkstra.calculateShortestPath(vertexA);
        print(Arrays.asList(vertexA, vertexB, vertexC,vertexD,vertexE, vertexF));



	Vertex<Integer> v0 = new Vertex<>(0);
	Vertex<Integer> v1 = new Vertex<>(1);
	Vertex<Integer> v2 = new Vertex<>(2);
	Vertex<Integer> v3 = new Vertex<>(3);
	Vertex<Integer> v4 = new Vertex<>(4);

    v0.setAdjacents(Arrays.asList(v1, v4));
    v1.setAdjacents(Arrays.asList(v3, v2));
    v4.setAdjacents(Arrays.asList(v4, v0));
    v2.setAdjacents(Arrays.asList(v1, v3));

    BFS<Integer> bfs = new BFS<>(v1);
    bfs.traverse();
    }
}
