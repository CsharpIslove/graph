package com.company;

import java.util.*;

public class WeightedVertex implements Comparable<WeightedVertex>{
        private String name;
        private Integer distance = Integer.MAX_VALUE;
        private List<WeightedVertex> shortest = new LinkedList<>();
        private Map<WeightedVertex, Integer> adjacentVertices = new HashMap<>();

        public WeightedVertex(String name) {
            this.name = name;
        }

        public void addVertex(WeightedVertex WeightedVertex, int weight){
            adjacentVertices.put(WeightedVertex, weight);
        }

        public int compareTo(WeightedVertex WeightedVertex){
            return Integer.compare(distance, WeightedVertex.getDistance());
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getDistance() {
            return distance;
        }

        public void setDistance(Integer distance) {
            this.distance = distance;
        }

        public List<WeightedVertex> getShortest() {
            return shortest;
        }

        public void setShortest(List<WeightedVertex> shortest) {
            this.shortest = shortest;
        }

        public Map<WeightedVertex, Integer> getAdjacentVertices() {
            return adjacentVertices;
        }

        public void setAdjacentVertices(Map<WeightedVertex, Integer> adjacentVertices) {
            this.adjacentVertices = adjacentVertices;
        }
    }
