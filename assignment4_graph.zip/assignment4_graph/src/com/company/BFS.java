package com.company;

import java.util.LinkedList;
import java.util.Queue;

public class BFS<T> {
    private Vertex<T> initial;

    public BFS(Vertex<T> initial){
        this.initial = initial;
    }

    public void traverse(){
        Queue<Vertex<T>> queue = new LinkedList<>();
        queue.add(initial);
        while (!queue.isEmpty()){
            Vertex<T> current = queue.poll();
            if(!current.isVisited()){
                current.setVisited(true);
                System.out.println("Vertex: " + current.getData());
                queue.addAll(current.getAdjacents());
            }
        }
    }
}
