package com.company;


import java.util.*;
import java.util.stream.Stream;

public class Dijkstra {
    public void calculateShortestPath(WeightedVertex source){
        source.setDistance(0);
        Set<WeightedVertex> settledVertices = new HashSet<>();
        Queue<WeightedVertex> unsettledVertices = new PriorityQueue<>(Collections.singleton(source));
        while (!unsettledVertices.isEmpty()){
            WeightedVertex currentVertex = unsettledVertices.poll();
            currentVertex.getAdjacentVertices().entrySet().stream().
                    filter(entry -> !settledVertices.contains(entry.getKey())).forEach(entry ->{
                        calculatePath(entry.getKey(), entry.getValue(), currentVertex);
                        unsettledVertices.add(entry.getKey());
                    });
            settledVertices.add(currentVertex);
        }
    }
    private void calculatePath(WeightedVertex adjacentVertex, Integer weight, WeightedVertex sourceVertex){
        Integer newDistance = sourceVertex.getDistance() + weight;
        if(newDistance < adjacentVertex.getDistance()){
            adjacentVertex.setDistance(newDistance);
            adjacentVertex.setShortest(Stream.concat(sourceVertex.getShortest().stream(), Stream.of(sourceVertex)).toList());
        }
    }
}
